# Carte d'eligibilite au programme ALABRI

## Données utilisées

* [PPRi Eurométropole de Strasbourg – Inondation par remontée de nappe (zonage)](https://data.strasbourg.eu/explore/dataset/ppri-zonage-rn/information/) (où l'on ne considère inondable que les zones vertes)
* [PPRi Eurométropole de Strasbourg – Inondation par débordement (zonage)](https://data.strasbourg.eu/explore/dataset/ppri-zonage-ipd/information/)
* [PPRi de la Bruche – Inondation par débordement (zonage)](https://data.strasbourg.eu/explore/dataset/ppri_bruche_ipd_zonage/information/)
* [Coulées d'eaux boueuses](https://data.strasbourg.eu/explore/dataset/coulees-eaux-boueuses/information/)
* [Parcelles cadastrales](https://data.strasbourg.eu/explore/dataset/parcelles_cadastrales/information/)