async function verifIntersection(parcelle, alea) {
    const polygon = bboxToOdsPolygon(turf.bbox(parcelle.geo_shape));
    const url = `https://data.strasbourg.eu/api/records/1.0/search/?dataset=${alea}&q=&geofilter.polygon=${polygon}`;
    
    return fetch(url)
        .then(response => response.json())
        .then(data => {
            const geometries = data.records.map(record => record.fields.geo_shape);
            const clippedGeometries = geotoolbox.clip(geometries, { clip: parcelle.geo_shape });
            const features = clippedGeometries.features;
            //const unionedFeature = turf.union(...clippedGeometries.features);
            // const touch = turf.booleanIntersects(clippedGeometries, parcelle.geo_shape);
            return features;
        });
}
