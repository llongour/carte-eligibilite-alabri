const bounds = [
  [7.1521, 48.109265],
  [8.344116, 48.9694],
];

const map = new maplibregl.Map({
  container: "map",
  style: {
    'version': 8,
    'sources': {
        'raster-tiles': {
            'type': 'raster',
            'tiles': [
                'https://adict.strasbourg.eu/mapproxy/service?VERSION=1.1.0&1=2&SERVICE=WMS&REQUEST=GetMap&VERSION=1.1.1&LAYERS=monstrasbourg&STYLES=&FORMAT=image%2Fpng&TRANSPARENT=false&HEIGHT=256&WIDTH=256&SRS=EPSG%3A3857&BBOX={bbox-epsg-3857}'
            ],
            'tileSize': 256
        }
    },
    'layers': [
        {
            'id': 'simple-tiles',
            'type': 'raster',
            'source': 'raster-tiles',
            'minzoom': 0,
            'maxzoom': 22
        }
    ]
},
  minZoom: 10,
  center: [7.7254, 48.5798],
  hash: true,
  maxBounds: bounds,
});

map.dragRotate.disable();

// Evenement declenche lorsque la carte est chargee
map.on("load", () => {
  // Ajout de la source et de la couche pour le masque EMS
  map.addSource("masque", {
    type: "geojson",
    data: "assets/masque.geojson",
  });
  map.addLayer({
    id: "masque-layer",
    type: "fill",
    source: "masque",
    paint: {
      "fill-color": "grey",
      "fill-opacity": 0.5,
    },
  });

  // Ajout de la source et de la couche pour Papi Zorn
  map.addSource("papizorn", {
    type: "geojson",
    data: "assets/papi_zorn.geojson",
  });
  map.addLayer({
    id: "papizorn-layer",
    type: "fill",
    source: "papizorn",
    paint: {
      "fill-color": "orange",
      "fill-opacity": 0,
    },
  });

  // Ajout de la source et de la couche pour les parcelles
  map.addSource("parcel-source", {
    type: "geojson",
    data: { type: "FeatureCollection", features: [] },
  });
  map.addLayer({
    id: "parcel-layer",
    type: "fill",
    source: "parcel-source",
    paint: {
      "fill-color": "blue",
      "fill-opacity": 0.3,
    },
  });
  
  // Ajout des contrôles à la carte
  map.addControl(new MaplibreGeocoder(geocoderApi, {maplibregl}));
  map.addControl(new maplibregl.GeolocateControl({positionOptions: {enableHighAccuracy: true},trackUserLocation: true}));
  map.addControl(new maplibregl.NavigationControl({ showCompass: false }));
});

// Evenement declenche lorsqu'un clic est effectue sur la carte
map.on("click", function (e) {
  // Recuperation des coordonnees du clic
  var coordinates = e.lngLat;
  const lat = coordinates.lat;
  const lon = coordinates.lng;
  

  // Recuperation des entites du masque rendues à l'emplacement du clic
  const featuresMasque = map.queryRenderedFeatures(e.point, {
    layers: ["masque-layer"],
  });

  // Si des entites de masque sont présentes, arrete le traitement
  if (featuresMasque.length > 0) {
    return;
  }

  // Recuperation des entites du PAPI Zorn à l'emplacement du clic
  const featuresPapiZorn = map.queryRenderedFeatures(e.point, {
    layers: ["papizorn-layer"],
  });

  // Si des entites PAPI Zorn sont presentes a l'emplacement du clic
  if (featuresPapiZorn.length > 0){
      
    Promise.all([
      recupererParcelle(lat, lon)
    ]).then(([parcelle]) => {
      aaaa = verifIntersection(parcelle, "ppri-zonage-ipd");
      console.log(aaaa);
    });
    
  
  }

});
